// API Configuration
const CONFIG = {
    API_ENDPOINT: 'https://f0ox7c23u9.execute-api.us-west-2.amazonaws.com/prod/upload',
    FILES_API_ENDPOINT: 'https://f0ox7c23u9.execute-api.us-west-2.amazonaws.com/prod/files'
};
